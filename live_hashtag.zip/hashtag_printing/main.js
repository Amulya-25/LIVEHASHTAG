    $(document).ready(function(){
               
                                
            
            $(window).scroll(function () {
      if ($(this).scrollTop() > 25) {
         $("#NAVBAR").addClass("changeColor");
          $(".navbar-link,#logo").addClass("changeText");
         
         
         $(".navbar-toggler-icon").addClass("icon_bg");
          
         
      }
      if ($(this).scrollTop() < 25) {
         $("#NAVBAR").removeClass("changeColor");
      $(".navbar-link,#logo").removeClass("changeText");
         
         $(".navbar-toggler-icon").removeClass("icon_bg");
        
      }
   });
        
          
       
});

       
            
     
        